export const BaseUrl = {
    baseApiUrl: "https://localhost:44386/api/"
  }