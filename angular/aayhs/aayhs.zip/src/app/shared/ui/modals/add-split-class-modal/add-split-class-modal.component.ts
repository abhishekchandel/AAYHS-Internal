import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-split-class-modal',
  templateUrl: './add-split-class-modal.component.html',
  styleUrls: ['./add-split-class-modal.component.scss']
})
export class AddSplitClassModalComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
