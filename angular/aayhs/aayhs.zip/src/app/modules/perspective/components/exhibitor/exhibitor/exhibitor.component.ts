import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-exhibitor',
  templateUrl: './exhibitor.component.html',
  styleUrls: ['./exhibitor.component.scss']
})
export class ExhibitorComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
